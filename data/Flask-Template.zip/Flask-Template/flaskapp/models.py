from datetime import datetime
from flaskapp import db

class Model1(db.Model):
    pass