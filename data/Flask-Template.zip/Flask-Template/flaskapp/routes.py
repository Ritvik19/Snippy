from flask import render_template, url_for, flash, redirect, request
from flaskapp import app, db
from flaskapp.forms import *
from flaskapp.models import *

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')